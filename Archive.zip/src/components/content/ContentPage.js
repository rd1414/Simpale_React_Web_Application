import React from 'react';
import {Media, Progress } from 'reactstrap';
import Delay from 'react-delay';

class ContentPage extends React.Component {
render(){
return(
 
<div className="container">

<div className="jumbotron">
  <h1 className="display-4">Content_1 Page</h1>
  <p className="lead">This is a simple React Application..</p>
  <hr className="my-4"></hr>

</div>


</div>
 
     );  
    }
    
}
export default ContentPage;