import React from 'react';
import {Link} from 'react-router';



class HomePage extends React.Component{
    
render(){
    return(
<div className="container">

<div className="jumbotron">
  <h1 className="display-4">404</h1>
  <p className="lead">The page is not found...</p>
  <hr className="my-4"></hr>

</div>


</div>


     );
    }
}

export default HomePage;