import React from 'react';
import {Link, IndexLink} from 'react-router';

const Footer = () => {
return(


<footer className="footer">
      <div className="container">
      <p className="text-center">Copyright @2019 | Designed by <a href="/">React App</a></p>
      </div>
    </footer>
);
};

export default Footer;